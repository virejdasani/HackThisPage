## I made a browser extension called "Hack This Page" with which you can edit or 'hack' any website with ease. 
> (Download links at the end of the post)

### Let me show you what I'm talking about:

![Virej-140M subscribers-youtube](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/ajzcku4pvg74sw93m6d2.png) 

### - Yes, I did give myself more subscribers than PewDiePie and a video with 4 Billion views
### - And no, I didn't use the developer tools (inspect element, etc.)


## So how did I do it?


- Essentially, once you add the extension and click the hack button, you can edit webpages like a text document without ever opening the developer tools!

- This makes it very easy to use to prank your friends and requires no programming skills


#### This is how easy it is to use the extension:
> https://www.youtube.com/watch?v=678LAl7E76U

## Download Hack This Page for [Google Chrome](https://chrome.google.com/webstore/detail/hack-this-page/nbfegodimhenhkghjeppighcbpdinhdp) or [Firefox](https://addons.mozilla.org/en-US/firefox/addon/hack-this-website/)


Please leave a review on the extension and feel free to ask me any questions you may have.
