# HackThisPage
### A Google Chrome extension with which you can 'Hack' any webpage ;)

<img alt="Meeting Assistant" src="https://github.com/virejdasani/HackThisPage/blob/master/assets/img/icon.png?raw=true" height="200px" />

See it in action here:
https://www.youtube.com/watch?v=678LAl7E76U

The download link will be posted as soon as the Chrome webstore accepts the extension 👍
